const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

router.post('/signup', authController.signup);
router.post('/signin', authController.signin);
router.get('/getMe', authController.getMe);
router.get('/logout', authController.logout);

module.exports = router;

/**
 * Microsoft Windows [Version 10.0.22621.3593]
(c) Корпорация Майкрософт (Microsoft Corporation). Все права защищены.

C:\Users\HPUser\Desktop\loyiha2>node "c:\Users\HPUser\Desktop\loyiha2\client\routes\authRoutes.js"
c:\Users\HPUser\node_modules\express\lib\router\route.js:216
        throw new Error(msg);
        ^

Error: Route.post() requires a callback function but got a [object Undefined]
    at Route.<computed> [as post] (c:\Users\HPUser\node_modules\express\lib\router\route.js:216:15)
    at proto.<computed> [as post] (c:\Users\HPUser\node_modules\express\lib\router\index.js:521:19)
    at Object.<anonymous> (c:\Users\HPUser\Desktop\loyiha2\client\routes\authRoutes.js:5:8)
    at Module._compile (node:internal/modules/cjs/loader:1368:14)    
    at Module._extensions..js (node:internal/modules/cjs/loader:1426:10)
    at Module.load (node:internal/modules/cjs/loader:1205:32)        
    at Module._load (node:internal/modules/cjs/loader:1021:12)       
    at Function.executeUserEntryPoint [as runMain] (node:internal/modules/run_main:142:12)
    at node:internal/main/run_main_module:28:49

Node.js v21.7.1

C:\Users\HPUser\Desktop\loyiha2>
 * 
 */
