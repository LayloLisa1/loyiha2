const express = require('express');
const router = express.Router();
const fileController = require('../controllers/fileController');

router.post('/upload', fileController.uploadFile);
router.get('/list', fileController.listFiles);
router.get('/:id', fileController.getFile);
router.delete('/:id', fileController.deleteFile);
router.get('/download/:id', fileController.downloadFile);
router.put('/:id', fileController.updateFile);

module.exports = router;
