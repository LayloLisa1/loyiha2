const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/User');


exports.createUser = async (login, password) => {
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ login, password: hashedPassword });
    await newUser.save();
};

exports.authenticateUser = async (login, password) => {
    const user = await User.findOne({ login });
    if (!user) {
        throw new Error('User not found');
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
        throw new Error('Invalid password');
    }

    const token = jwt.sign({ userId: user._id }, secret, { expiresIn: '1h' });
    return token;
};

/**\client\services\userCourseService.js"
node:internal/modules/cjs/loader:1145
  throw err;
  ^

Error: Cannot find module 'bcrypt'
Require stack:
- c:\Users\HPUser\Desktop\loyiha2\client\services\userCourseService.js
    at Module._resolveFilename (node:internal/modules/cjs/loader:1142:15)
    at Module._load (node:internal/modules/cjs/loader:983:27)        
    at Module.require (node:internal/modules/cjs/loader:1230:19)     
    at require (node:internal/modules/helpers:179:18)
    at Object.<anonymous> (c:\Users\HPUser\Desktop\loyiha2\client\services\userCourseService.js:1:16)
    at Module._compile (node:internal/modules/cjs/loader:1368:14)    
    at Module._extensions..js (node:internal/modules/cjs/loader:1426:10)
    at Module.load (node:internal/modules/cjs/loader:1205:32)        
    at Module._load (node:internal/modules/cjs/loader:1021:12)       
    at Function.executeUserEntryPoint [as runMain] (node:internal/modules/run_main:142:12) {
  code: 'MODULE_NOT_FOUND',
  requireStack: [
    'c:\\Users\\HPUser\\Desktop\\loyiha2\\client\\services\\userCourseService.js'
  ]
}

Node.js v21.7.1

C:\Users\HPUser\Desktop\loyiha2> */