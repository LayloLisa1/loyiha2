const File = require('../models/File');

exports.uploadFile = (req, res) => {
    res.status(200).json({ message: 'File uploaded', fileId: 'fileId' });
};

exports.listFiles = (req, res) => {
    File.find()
        .then(files => res.status(200).json(files))
        .catch(err => res.status(500).json({ message: 'Error listing files', err }));
};

exports.getFile = (req, res) => {
    File.findById(req.params.id)
        .then(file => {
            if (!file) return res.status(404).json({ message: 'File not found' });
            res.status(200).json(file);
        })
        .catch(err => res.status(500).json({ message: 'Error getting file', err }));
};

exports.deleteFile = (req, res) => {
    File.findByIdAndDelete(req.params.id)
        .then(() => res.status(200).json({ message: 'File deleted' }))
        .catch(err => res.status(500).json({ message: 'Error deleting file', err }));
};

exports.downloadFile = (req, res) => {
    res.status(200).json({ message: 'File downloaded' });
};

exports.updateFile = (req, res) => {
    File.findByIdAndUpdate(req.params.id, { filename: req.body.filename }, { new: true })
        .then(() => res.status(200).json({ message: 'File updated' }))
        .catch(err => res.status(500).json({ message: 'Error updating file', err }));
};
