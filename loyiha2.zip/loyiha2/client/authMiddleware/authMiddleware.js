const jwt = require('jsonwebtoken');

const authMiddleware = (req, res, next) => {
    const token = req.headers['authorization'];
    if (!token) return res.status(401).json({ message: 'No token provided' });

    jwt.verify(token.split(' ')[1], 'your_secret_key', (err, decoded) => {
        if (err) return res.status(500).json({ message: 'Failed to authenticate token' });

        req.userId = decoded.id;
        next();
    });
};

module.exports = authMiddleware;

/**
 * Microsoft Windows [Version 10.0.22621.3593]
(c) Корпорация Майкрософт (Microsoft Corporation). Все права защищены.

C:\Users\HPUser\Desktop\loyiha2>node "c:\Users\HPUser\Desktop\loyiha2\client\middleware\authMiddleware.js"
node:internal/modules/cjs/loader:1145
  throw err;
  ^

Error: Cannot find module 'jsonwebtoken'
Require stack:
- c:\Users\HPUser\Desktop\loyiha2\client\middleware\authMiddleware.js
    at Module._resolveFilename (node:internal/modules/cjs/loader:1142:15)
    at Module._load (node:internal/modules/cjs/loader:983:27)
    at Module.require (node:internal/modules/cjs/loader:1230:19)
    at require (node:internal/modules/helpers:179:18)
    at Object.<anonymous> (c:\Users\HPUser\Desktop\loyiha2\client\middleware\authMiddleware.js:1:13)
    at Module._compile (node:internal/modules/cjs/loader:1368:14)    
    at Module._extensions..js (node:internal/modules/cjs/loader:1426:10)
    at Module.load (node:internal/modules/cjs/loader:1205:32)        
    at Module._load (node:internal/modules/cjs/loader:1021:12)       
    at Function.executeUserEntryPoint [as runMain] (node:internal/modules/run_main:142:12) {
  code: 'MODULE_NOT_FOUND',
  requireStack: [
    'c:\\Users\\HPUser\\Desktop\\loyiha2\\client\\middleware\\authMiddleware.js'
  ]
}

Node.js v21.7.1

C:\Users\HPUser\Desktop\loyiha2>
 */